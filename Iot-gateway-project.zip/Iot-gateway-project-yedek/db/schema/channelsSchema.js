var mongoose = require('mongoose');
mongoose.connect('mongodb://DESKTOP-AKPMR9J/wheather-station');
var Schema = mongoose.Schema;
var channelsSchema =new Schema({ 
 name : String ,
 channel_id:  { type: Number , default:3},
 user_id: { type: Number , default:1},
 _id: { type: Number, default:1},
 latitude : Number,
 longitude : Number,
 date: { type: Date, default:Date.now },
 data: Number,
 device_id: Number
}) ;
var channelModel = mongoose.model('channel', channelsSchema);

module.exports = channelModel