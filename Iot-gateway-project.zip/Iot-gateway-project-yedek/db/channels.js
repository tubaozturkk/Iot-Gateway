var channelsSchema =require('./schema/channelsSchema');
module.exports = {
  create : function(data, callBack){
      var channel = new channelsSchema(data);
      channel.save(callBack);
  },
  read: function(data,callBack){
      var channel = new channelsSchema(data);
      channel.save(callBack);

  },
  update : function(data,callBack){
      var channel = new channelsSchema(data);      
      channel.save(callBack);

  },
  delete : function(data,callBack){
      var channel = new channelsSchema(data);
      channel.save(callBack);

  }


};

