var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var channelDetail =  require('./channelDetail');
var channel = require('../db/channels.js');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post('/',function(req,res,next){ 

  channel.create(req.body, function(err, createdObject){
      if (err) {
       //   res.send(err);
     }
      res.redirect('/channelDetail');
      // res.send(createdObject);
    });
  });
  

    router.get('/',function(req,res,next){ 
      channel.read(req.params.channel_id,function(err , name){
          if (err) {
              res.send(err)
          }
          if (name) {
              res.send(name)
          } else {
              res.send("No channel found with that ID")
          }

       });  
    });     
    router.delete('/delete',function(req,res,next){ 
       channel.delete(req.body.channel_id,function(err,channel){
         var response = {
        message: "Channel successfully deleted",
        id: channel_id
          };
        res.send(response);
        res.redirect('/channelDetail');
           });
      });     
        
    
  



module.exports = router;
