var express = require('express');
var router = express.Router();
var channel = require('../db/channels.js');
var channelsSchema = require ('../db/schema/channelsSchema.js');

/* GET users listing. */
router.get('/', function(req, res, next) {
  
  res.render('channelDetail' , {title:'detail'} );
});


router.put('/',function(req,res,next){ 
    
      channel.findById(req.body.channel_id,function(err,updatingObject){
        if (err) {
        res.status(500).send(err);
                 } 
       else {               
         updatingObject.name = req.body.name || updatingObject.name;
         updatingObject.latitude = req.body.latitude || updatingObject.latitude;
         updatingObject.longitude = req.body.longitude || updatingObject.longitude;
        
      };
      updatingObject.save(function (err, object) {
            if (err) {
                res.status(500).send(err)
            }
            res.send(object);
            console.log(updatingObject.name);
          });
        });
    });    
module.exports = router;